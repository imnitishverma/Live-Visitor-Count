=== Live Visitor Count ===
Contributors: nitishverma
Donate link: https://www.nitishverma.com/
Tags: visitor counter, page views, analytics, live visitors
Requires at least: 5.6
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Live Visitor Count is a simple, fast, and easy-to-use plugin to track and display page views and live visitors on your WordPress site.
