<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

// Define the table name
$table_name = $wpdb->prefix . "lvc_page_views";

// Use $wpdb->prepare() to safely interpolate the table name
$sql = $wpdb->prepare("DROP TABLE IF EXISTS %s", $table_name);

// Suppress warnings for direct database queries during uninstallation
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
$wpdb->query($sql);
// phpcs:enable

// Delete plugin options
delete_option('lvc_settings');
?>