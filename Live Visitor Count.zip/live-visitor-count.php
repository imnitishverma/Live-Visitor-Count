<?php
/**
 * Plugin Name:       Live Visitor Count
 * Plugin URI:        https://wordpress.org/plugins/live-visitor-count/
 * Description:       A simple plugin to track live visitors and page views.
 * Version:           1.0.0
 * Author:            Nitish Verma
 * Author URI:        https://www.nitishverma.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       live-visitor-count
 * Requires at least: 5.6
 * Tested up to:      6.7
 * Requires PHP:      7.4
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('LVC_PLUGIN_DIR', plugin_dir_path(__FILE__));
defined('LVC_PLUGIN_URL') or define('LVC_PLUGIN_URL', plugin_dir_url(__FILE__));

// Activation Hook
function lvc_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . "lvc_page_views";
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        post_id BIGINT(20) NOT NULL,
        views INT(11) DEFAULT 0,
        views_today INT(11) DEFAULT 0,
        last_view_date DATE NOT NULL
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'lvc_activate');

// Add Plugin Menu to Dashboard Sidebar
function lvc_add_admin_menu() {
    add_menu_page(
        'Live Visitor Count',
        'Live Visitors',
        'manage_options',
        'lvc_dashboard',
        'lvc_dashboard_page',
        'dashicons-chart-bar',
        25
    );
}
add_action('admin_menu', 'lvc_add_admin_menu');

// Admin Dashboard Page with Modern Design
function lvc_dashboard_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . "lvc_page_views";

    // Fetch data with caching
    $total_views = wp_cache_get('lvc_total_views', 'lvc_cache');
    if (false === $total_views) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $total_views = $wpdb->get_var("SELECT SUM(views) FROM $table_name");
        wp_cache_set('lvc_total_views', $total_views, 'lvc_cache', 3600); // Cache for 1 hour
    }

    $today_views = wp_cache_get('lvc_today_views', 'lvc_cache');
    if (false === $today_views) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $today_views = $wpdb->get_var("SELECT SUM(views_today) FROM $table_name WHERE last_view_date = CURDATE()");
        wp_cache_set('lvc_today_views', $today_views, 'lvc_cache', 3600); // Cache for 1 hour
    }

    $top_posts = wp_cache_get('lvc_top_posts', 'lvc_cache');
    if (false === $top_posts) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $top_posts = $wpdb->get_results("SELECT post_id, views FROM $table_name ORDER BY views DESC LIMIT 10");
        wp_cache_set('lvc_top_posts', $top_posts, 'lvc_cache', 3600); // Cache for 1 hour
    }

    $all_posts = wp_cache_get('lvc_all_posts', 'lvc_cache');
    if (false === $all_posts) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $all_posts = $wpdb->get_results("SELECT post_id, views FROM $table_name ORDER BY views DESC LIMIT 20");
        wp_cache_set('lvc_all_posts', $all_posts, 'lvc_cache', 3600); // Cache for 1 hour
    }

    // Output dashboard HTML
    echo '<div class="wrap">';
    echo '<h1 style="color: #0073aa;">📊 Live Visitor Count Dashboard</h1>';
    echo '<div style="background: #f9f9f9; padding: 15px; border-radius: 5px;">';
    echo '<h2>Total Views: <span style="color: #21759b;">' . esc_html($total_views ?: 0) . '</span></h2>';
    echo '<h2>Views Today: <span style="color: #d63638;">' . esc_html($today_views ?: 0) . '</span></h2>';
    echo '</div>';

    // Top 10 Most Viewed Pages
    echo '<h2 style="margin-top: 20px;">🏆 Top 10 Most Viewed Pages</h2>';
    echo '<table class="widefat fixed" style="background: white;">';
    echo '<thead><tr><th>Page</th><th>Views</th></tr></thead><tbody>';
    foreach ($top_posts as $post) {
        echo '<tr><td><a href="' . esc_url(get_permalink($post->post_id)) . '" target="_blank">' . esc_html(get_the_title($post->post_id)) . '</a></td><td>' . esc_html($post->views) . '</td></tr>';
    }
    echo '</tbody></table>';

    // All Pages Views (Top 20)
    echo '<h2 style="margin-top: 20px;">📌 All Pages Views (Top 20)</h2>';
    echo '<table class="widefat fixed" style="background: white;">';
    echo '<thead><tr><th>Page</th><th>Views</th></tr></thead><tbody>';
    foreach ($all_posts as $post) {
        echo '<tr><td><a href="' . esc_url(get_permalink($post->post_id)) . '" target="_blank">' . esc_html(get_the_title($post->post_id)) . '</a></td><td>' . esc_html($post->views) . '</td></tr>';
    }
    echo '</tbody></table>';

    echo '</div>';
}

// Enqueue Scripts & Styles
function lvc_enqueue_assets() {
    wp_enqueue_style('lvc-style', LVC_PLUGIN_URL . 'assets/css/style.css');
    wp_enqueue_script('lvc-script', LVC_PLUGIN_URL . 'assets/js/script.js', ['jquery'], null, true);
    wp_localize_script('lvc-script', 'lvc_ajax', ['ajax_url' => admin_url('admin-ajax.php')]);
}
add_action('wp_enqueue_scripts', 'lvc_enqueue_assets');

// Track Page Views
function lvc_track_views() {
    if (!is_singular()) return;
    global $wpdb, $post;

    $table_name = $wpdb->prefix . "lvc_page_views";
    $post_id = $post->ID;
    $today = current_time('Y-m-d');

    // Fetch row with caching
    $row = wp_cache_get('lvc_post_' . $post_id, 'lvc_cache');
    if (false === $row) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE post_id = %d", $post_id));
        wp_cache_set('lvc_post_' . $post_id, $row, 'lvc_cache', 3600); // Cache for 1 hour
    }

    if ($row) {
        $views = $row->views + 1;
        $views_today = ($row->last_view_date == $today) ? $row->views_today + 1 : 1;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update($table_name, ['views' => $views, 'views_today' => $views_today, 'last_view_date' => $today], ['post_id' => $post_id]);
    } else {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->insert($table_name, ['post_id' => $post_id, 'views' => 1, 'views_today' => 1, 'last_view_date' => $today]);
    }

    // Clear cache for updated post
    wp_cache_delete('lvc_post_' . $post_id, 'lvc_cache');
    wp_cache_delete('lvc_total_views', 'lvc_cache');
    wp_cache_delete('lvc_today_views', 'lvc_cache');
    wp_cache_delete('lvc_top_posts', 'lvc_cache');
    wp_cache_delete('lvc_all_posts', 'lvc_cache');
}
add_action('wp_head', 'lvc_track_views');

// Display View Counter on Frontend
function lvc_display_views($content) {
    if (!is_singular()) return $content;
    
    global $wpdb, $post;
    $table_name = $wpdb->prefix . "lvc_page_views";
    $post_id = $post->ID;

    // Fetch views with caching
    $views = wp_cache_get('lvc_views_' . $post_id, 'lvc_cache');
    if (false === $views) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $views = $wpdb->get_var($wpdb->prepare("SELECT views FROM $table_name WHERE post_id = %d", $post_id));
        wp_cache_set('lvc_views_' . $post_id, $views, 'lvc_cache', 3600); // Cache for 1 hour
    }

    $views_today = wp_cache_get('lvc_views_today_' . $post_id, 'lvc_cache');
    if (false === $views_today) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $views_today = $wpdb->get_var($wpdb->prepare("SELECT views_today FROM $table_name WHERE post_id = %d", $post_id));
        wp_cache_set('lvc_views_today_' . $post_id, $views_today, 'lvc_cache', 3600); // Cache for 1 hour
    }

    $views = $views ?: 0;
    $views_today = $views_today ?: 0;

    // Output view counter
    $counter_html = "<div class='lvc-counter' style='padding:10px; background:#f1f1f1; text-align:center; border-radius:5px; margin:10px 0;'>
        <strong>👀 Views: " . esc_html($views) . "</strong> | <span style='color:#d63638;'>📅 Today: " . esc_html($views_today) . "</span>
    </div>";

    return $counter_html . $content;
}
add_filter('the_content', 'lvc_display_views');